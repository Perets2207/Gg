package net.vulkanmod.interfaces;

import net.vulkanmod.vulkan.Pipeline;

public interface ShaderMixed {

    Pipeline getPipeline();
}
