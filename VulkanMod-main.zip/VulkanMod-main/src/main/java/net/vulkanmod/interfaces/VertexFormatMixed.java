package net.vulkanmod.interfaces;

public interface VertexFormatMixed {

    int getOffset(int i);
}
